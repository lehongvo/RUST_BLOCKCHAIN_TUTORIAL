pub fn hello() {
    println!("Hello from my_library!");
}

pub fn get_value() -> String {
   let value = String::from("Hello, world!");
   return value;
}